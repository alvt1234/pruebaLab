
public interface JuegoAhorcado {
    
    void inicializarPalabraSecreta();
    void jugar();
}
